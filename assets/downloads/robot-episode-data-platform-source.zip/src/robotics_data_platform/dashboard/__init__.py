"""Read-only evidence dashboard."""
